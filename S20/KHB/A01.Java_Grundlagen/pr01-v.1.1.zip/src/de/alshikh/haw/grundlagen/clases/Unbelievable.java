/*#####################################################################
# Assigment sheet A01: Java Basics.
#
# Author:: Hani Alshikh
#
#######################################################################*/

package de.alshikh.haw.grundlagen.clases;

public class Unbelievable {
    static Integer i = 42;

    public static void main(String[] args) {
        if (i == 42)
            System.out.println("Unbelievable");
    }

}
